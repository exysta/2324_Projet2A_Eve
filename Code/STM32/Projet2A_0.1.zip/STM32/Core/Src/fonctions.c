#include "main.h"


int sinus[] = {0,4,8,16};

int ordre(int angle){

	int DTVCTR = 0;
	int phase= 1;
	int courant_A = 0;
	int courant_B = 0;


	//Calculer la polarisation de A & de B

	if ( 0 <= angle <= 180){
		phase = 0;
	}

	DTVCTR |= phase<<17;


	// Courant

	courant_A = courant(angle,1);
	courant_B = courant(angle,0);


	DTVCTR |= courant_A<<9;
	DTVCTR |= courant_B;

	return DTVCTR;

}


int courant(int angle, int numero){

	if (numero ==1){ //On gère le courant A

		if(0<= angle <=90 || 180<= angle <= 270){
			return sinus[angle%90];
		}
		else{
			return sinus[90-angle%90];
		}


	}
	else{ //On gère le courant B

		if(0<= angle <=90 || 180<= angle <= 270){
			return sinus[90-angle%90];
		}
		else{
			return sinus[angle%90];
		}

	}

}
